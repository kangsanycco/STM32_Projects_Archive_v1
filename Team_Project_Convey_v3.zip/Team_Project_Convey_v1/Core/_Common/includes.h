/*
 * includes.h
 *
 *  Created on: Jan 19, 2026
 *      Author: kangs
 */

#ifndef COMMON_INCLUDES_H_
#define COMMON_INCLUDES_H_

// drv_gpio.c
GPIO_PinState DRV_GPIO_Read(GPIO_TypeDef* port, uint16_t pin);

// bsp_gpio.c
int BSP_PLC_IsActive(void);

// drv_uart.c
void UART_ReportStatus(void);

#endif /* COMMON_INCLUDES_H_ */
