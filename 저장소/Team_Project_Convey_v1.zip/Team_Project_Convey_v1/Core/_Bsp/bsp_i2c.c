/*
 * bsp_i2c.c
 *
 *  Created on: Jan 17, 2026
 *      Author: kangs
 */

#ifndef BSP_BSP_I2C_C_
#define BSP_BSP_I2C_C_



#endif /* BSP_BSP_I2C_C_ */
