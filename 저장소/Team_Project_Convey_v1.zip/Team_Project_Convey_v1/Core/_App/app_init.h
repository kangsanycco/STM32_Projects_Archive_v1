/*
 * app_init.h
 *
 *  Created on: Jan 17, 2026
 *      Author: kangs
 */

#ifndef APP_APP_INIT_H_
#define APP_APP_INIT_H_



#endif /* APP_APP_INIT_H_ */
